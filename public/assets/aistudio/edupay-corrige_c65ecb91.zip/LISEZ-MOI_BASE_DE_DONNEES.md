# Connexion des interfaces (Parent ↔ Secrétariat) via Supabase

1. Supabase > votre projet > SQL Editor > coller tout `schema.sql` > Run (sans danger, réexécutable).
2. Vercel > Settings > Environment Variables : `VITE_SUPABASE_URL` et `VITE_SUPABASE_ANON_KEY`
   (ceux du MÊME projet Supabase où vous avez exécuté schema.sql), puis Redeploy.
3. Ouvrir le site parent et le lien secrétariat (`?espace=secretaire`) sur deux appareils :
   un paiement ou une demande faits d'un côté apparaissent en direct de l'autre.
