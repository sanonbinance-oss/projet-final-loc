import React from 'react';
import { SyncStatus } from '../services/sync';
import { SchoolStore } from '../services/store';

/** Bandeau d'état de la liaison avec la base : visible seulement quand il y a quelque chose à savoir. */
export const SyncBanner: React.FC<{ status: SyncStatus }> = ({ status }) => {
  if (status.error) {
    return (
      <div className="no-print bg-red-600 text-white text-xs px-4 py-2 flex flex-wrap items-center gap-x-3 gap-y-1" role="alert">
        <strong>Enregistrement refusé par la base :</strong>
        <span className="flex-1 min-w-[200px]">{status.error}</span>
        <button onClick={() => SchoolStore.retrySync()} className="underline font-semibold">Réessayer</button>
        <button onClick={() => SchoolStore.discardBlockedWrite()} className="underline opacity-80">Abandonner cette opération</button>
      </div>
    );
  }
  if (status.offline) {
    return (
      <div className="no-print bg-amber-500 text-slate-900 text-xs px-4 py-2" role="status">
        Connexion à la base indisponible — vos actions sont conservées
        {status.pending > 0 ? ` (${status.pending} en attente)` : ''} et seront envoyées automatiquement au retour du réseau.
      </div>
    );
  }
  if (!status.hydrated) {
    return (
      <div className="no-print bg-slate-800 text-white text-xs px-4 py-2" role="status">
        Chargement des données en direct…
      </div>
    );
  }
  if (status.pending > 0) {
    return (
      <div className="no-print bg-slate-700 text-white text-xs px-4 py-1.5" role="status">
        Envoi en cours ({status.pending})…
      </div>
    );
  }
  return null;
};
