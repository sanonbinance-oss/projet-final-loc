import { createClient } from '@supabase/supabase-js';

/**
 * Configuration Supabase.
 * Sur Vercel : Project > Settings > Environment Variables
 *   VITE_SUPABASE_URL       = https://xxxx.supabase.co
 *   VITE_SUPABASE_ANON_KEY  = clé "anon" / "publishable" du projet
 * (Après modification : Redeploy, car ces valeurs sont intégrées au build.)
 * Les valeurs ci-dessous ne servent que de secours si les variables sont absentes.
 */
const env = ((import.meta as unknown as { env?: Record<string, string | undefined> }).env ?? {}) as Record<
  string,
  string | undefined
>;

export const SUPABASE_URL: string = env.VITE_SUPABASE_URL || 'https://kotkvxsalfqyfjnxjsui.supabase.co';
export const SUPABASE_ANON_KEY: string =
  env.VITE_SUPABASE_ANON_KEY || 'sb_publishable_laRCB_Ree-_uzAAeEijpLg_U6f_f0aD';
export const SUPABASE_PROJECT_ID: string = SUPABASE_URL.replace('https://', '').split('.')[0];

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  realtime: { params: { eventsPerSecond: 10 } },
});

export interface SupabaseConnexionStatus {
  connecte: boolean;
  tablesExiste: boolean;
  message: string;
  codeErreur?: string;
  details?: string;
}

const TABLES_REQUISES = ['eleves', 'paiements', 'demandes_admission', 'tarifs_scolarite', 'inscriptions_annuelles'];

export function isTableMissingError(error: { code?: string; message?: string } | null | undefined): boolean {
  if (!error) return false;
  return (
    error.code === 'PGRST205' ||
    error.code === '42P01' ||
    !!error.message?.includes('Could not find the table') ||
    !!error.message?.includes('schema cache')
  );
}

/** Diagnostic de la liaison (utilisé par l'onglet « Passerelles & API »). */
export class SupabaseSyncService {
  static async testerConnexion(): Promise<SupabaseConnexionStatus> {
    try {
      const manquantes: string[] = [];
      for (const table of TABLES_REQUISES) {
        const { error } = await supabase.from(table).select('*', { count: 'exact', head: true });
        if (error) {
          if (isTableMissingError(error)) {
            manquantes.push(table);
            continue;
          }
          return {
            connecte: false,
            tablesExiste: false,
            codeErreur: error.code,
            message: `Accès refusé ou clé invalide sur « ${table} » : ${error.message}`,
            details: error.message,
          };
        }
      }
      if (manquantes.length > 0) {
        return {
          connecte: true,
          tablesExiste: false,
          message: `Connexion OK, mais tables absentes : ${manquantes.join(', ')}. Exécutez schema.sql dans le SQL Editor.`,
        };
      }
      return {
        connecte: true,
        tablesExiste: true,
        message: 'Liaison active : toutes les tables répondent. Les interfaces partagent la même base en direct.',
      };
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Erreur inconnue';
      return {
        connecte: false,
        tablesExiste: false,
        message: "Impossible de contacter Supabase (projet introuvable, en pause ou réseau coupé) : " + msg,
      };
    }
  }
}
