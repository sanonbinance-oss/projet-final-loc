import { supabase, isTableMissingError } from './supabaseClient';
import type { Row } from './mappers';

/**
 * File d'écriture vers Supabase ("outbox").
 *  - Les écritures partent DANS L'ORDRE (un élève est créé avant ses paiements).
 *  - Si le réseau coupe, elles sont gardées (localStorage) et rejouées automatiquement.
 *  - Si la base REFUSE une écriture (table absente, droit refusé, doublon...), la file
 *    s'arrête et l'erreur est AFFICHÉE : plus jamais d'échec silencieux.
 */

export type SyncOp =
  | { id: string; kind: 'upsert'; table: string; rows: Row[]; onConflict: string; ignoreDuplicates?: boolean }
  | { id: string; kind: 'delete'; table: string; match: Record<string, string | number> };

type NewSyncOp =
  | Omit<Extract<SyncOp, { kind: 'upsert' }>, 'id'>
  | Omit<Extract<SyncOp, { kind: 'delete' }>, 'id'>;

export interface SyncStatus {
  hydrated: boolean; // données chargées depuis Supabase au moins une fois
  loading: boolean;
  pending: number; // écritures en attente d'envoi
  offline: boolean; // Supabase injoignable (réseau coupé / projet en pause)
  live: boolean; // abonnement temps réel actif
  error?: string; // refus de la base (file bloquée)
}

const OUTBOX_KEY = 'edupay_outbox_v1';

type PgErr = { code?: string; message?: string } | null;

function loadQueue(): SyncOp[] {
  try {
    const raw = localStorage.getItem(OUTBOX_KEY);
    return raw ? (JSON.parse(raw) as SyncOp[]) : [];
  } catch {
    return [];
  }
}

function friendly(err: NonNullable<PgErr>): string {
  if (isTableMissingError(err)) return "Tables introuvables dans Supabase : exécutez le fichier schema.sql dans le SQL Editor.";
  switch (err.code) {
    case '42501':
      return "Accès refusé par Supabase (politiques RLS) : réexécutez schema.sql.";
    case '23505':
      return `Doublon refusé par la base (${err.message}).`;
    case '23503':
      return `Référence manquante en base (${err.message}).`;
    case '22P02':
    case '22007':
      return `Valeur invalide refusée par la base (${err.message}).`;
    default:
      return err.message || 'Erreur Supabase inconnue.';
  }
}

function isRetryable(err: NonNullable<PgErr>): boolean {
  if (!err.code) return true; // pas de code PostgREST => problème réseau
  return err.code === 'PGRST002' || err.code.startsWith('08') || err.code.startsWith('57');
}

const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

class Engine {
  private queue: SyncOp[] = typeof window !== 'undefined' ? loadQueue() : [];
  private running = false;
  private retryTimer: ReturnType<typeof setTimeout> | null = null;
  private retryDelay = 3000;
  private listeners = new Set<() => void>();
  /** Appelé quand on abandonne une écriture refusée : le store recharge la vérité du serveur. */
  onDiscard: (() => void) | null = null;

  private status: SyncStatus = {
    hydrated: false,
    loading: false,
    pending: 0,
    offline: false,
    live: false,
  };

  getStatus(): SyncStatus {
    return { ...this.status, pending: this.queue.length };
  }
  pendingOps(): SyncOp[] {
    return [...this.queue];
  }
  subscribe(fn: () => void) {
    this.listeners.add(fn);
    return () => {
      this.listeners.delete(fn);
    };
  }
  patch(p: Partial<SyncStatus>) {
    this.status = { ...this.status, ...p };
    this.listeners.forEach((l) => l());
  }

  private persist() {
    try {
      localStorage.setItem(OUTBOX_KEY, JSON.stringify(this.queue));
    } catch {
      /* quota : on garde au moins la file en mémoire */
    }
  }

  enqueue(op: NewSyncOp) {
    this.queue.push({ ...op, id: uid() } as SyncOp);
    this.persist();
    this.patch({});
    void this.flush();
  }

  private async exec(op: SyncOp): Promise<PgErr> {
    try {
      if (op.kind === 'upsert') {
        const { error } = await supabase
          .from(op.table)
          .upsert(op.rows, { onConflict: op.onConflict, ignoreDuplicates: !!op.ignoreDuplicates });
        return error;
      }
      let q = supabase.from(op.table).delete();
      for (const [k, v] of Object.entries(op.match)) q = q.eq(k, v);
      const { error } = await q;
      return error;
    } catch (e) {
      return { message: e instanceof Error ? e.message : 'Réseau indisponible' };
    }
  }

  async flush(): Promise<void> {
    if (this.running) return;
    this.running = true;
    try {
      while (this.queue.length > 0) {
        const err = await this.exec(this.queue[0]);
        if (!err) {
          this.queue.shift();
          this.persist();
          this.retryDelay = 3000;
          this.patch({ error: undefined, offline: false });
          continue;
        }
        if (isRetryable(err)) {
          this.patch({ offline: true });
          this.scheduleRetry();
        } else {
          console.error('[EduPay] Écriture refusée par Supabase :', err);
          this.patch({ error: friendly(err), offline: false });
        }
        return;
      }
      this.patch({ offline: false, error: undefined });
    } finally {
      this.running = false;
    }
  }

  private scheduleRetry() {
    if (this.retryTimer) return;
    this.retryTimer = setTimeout(() => {
      this.retryTimer = null;
      void this.flush();
    }, this.retryDelay);
    this.retryDelay = Math.min(this.retryDelay * 2, 30000);
  }

  /** Bouton « Réessayer ». */
  retry() {
    this.patch({ error: undefined });
    void this.flush();
  }

  /** Bouton « Abandonner » : on jette l'écriture refusée et on recharge l'état réel. */
  discardBlocked() {
    this.queue.shift();
    this.persist();
    this.patch({ error: undefined });
    this.onDiscard?.();
    void this.flush();
  }
}

export const SyncEngine = new Engine();
