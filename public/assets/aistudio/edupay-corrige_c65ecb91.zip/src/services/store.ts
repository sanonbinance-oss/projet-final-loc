import { AdmissionRequest, Payment, SchoolInfo, Student, TuitionTariff } from '../types';
import { supabase, isTableMissingError } from './supabaseClient';
import { SyncEngine } from './sync';
import {
  Row,
  admissionFromRow,
  admissionToRow,
  paymentFromRow,
  paymentToRow,
  studentFromRow,
  studentToRow,
  tariffFromRow,
  tariffToRow,
} from './mappers';

export const CURRENT_SCHOOL_YEAR = '2027-2028';
export const PREVIOUS_SCHOOL_YEAR = '2026-2027';

export const DEFAULT_SCHOOL_INFO: SchoolInfo = {
  nom: 'Groupe Scolaire Excellence & Avenir (Collège & Enseignement Technique)',
  devise: 'Discipline - Travail - Réussite',
  slogan: 'L excellence générale et technologique au service de la nation',
  anneeScolaire: '2027 - 2028',
  anneePrecedente: '2026 - 2027',
  telephone: '+226 25 36 78 90 / +226 70 00 11 22',
  email: 'contact@excellence-avenir.bf',
  adresse: 'Secteur 28, Boulevard Charles de Gaulle',
  ville: 'Ouagadougou',
  pays: 'Burkina Faso',
  agrementMinisteriel: 'Arrêté N° 2023-0482/MENAPLN/SG/DREPS (Filières Générales & Techniques)',
};

/**
 * Grille tarifaire officielle par défaut intégrant strictement :
 * 1. Collège : 6ème, 5ème, 4ème, 3ème
 * 2. Lycée Général : 2nde A, 2nde C, 1ère A, 1ère D, Tle A, Tle D
 * 3. Enseignement Technique & Professionnel : Bac Pro 1, Bac Pro 2, BEP 1, BEP 2, C', D'
 */
export const DEFAULT_TARIFS_2027_2028: TuitionTariff[] = [
  // --- CYCLE COLLÈGE ---
  {
    id: 'TARIF_6EME',
    anneeScolaire: '2027-2028',
    niveau: '6ème',
    montantScolarite: 160000,
    fraisInscription: 25000,
    fraisAnnexes: 15000,
    totalExigible: 200000,
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'TARIF_5EME',
    anneeScolaire: '2027-2028',
    niveau: '5ème',
    montantScolarite: 160000,
    fraisInscription: 25000,
    fraisAnnexes: 15000,
    totalExigible: 200000,
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'TARIF_4EME',
    anneeScolaire: '2027-2028',
    niveau: '4ème',
    montantScolarite: 175000,
    fraisInscription: 25000,
    fraisAnnexes: 15000,
    totalExigible: 215000,
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'TARIF_3EME',
    anneeScolaire: '2027-2028',
    niveau: '3ème',
    montantScolarite: 190000,
    fraisInscription: 30000,
    fraisAnnexes: 20000,
    totalExigible: 240000,
    updatedAt: new Date().toISOString(),
  },

  // --- CYCLE LYCÉE ENSEIGNEMENT GÉNÉRAL ---
  {
    id: 'TARIF_2NDE_A',
    anneeScolaire: '2027-2028',
    niveau: '2nde A',
    montantScolarite: 210000,
    fraisInscription: 30000,
    fraisAnnexes: 20000,
    totalExigible: 260000,
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'TARIF_2NDE_C',
    anneeScolaire: '2027-2028',
    niveau: '2nde C',
    montantScolarite: 215000,
    fraisInscription: 30000,
    fraisAnnexes: 20000,
    totalExigible: 265000,
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'TARIF_1ERE_A',
    anneeScolaire: '2027-2028',
    niveau: '1ère A',
    montantScolarite: 225000,
    fraisInscription: 35000,
    fraisAnnexes: 20000,
    totalExigible: 280000,
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'TARIF_1ERE_D',
    anneeScolaire: '2027-2028',
    niveau: '1ère D',
    montantScolarite: 230000,
    fraisInscription: 35000,
    fraisAnnexes: 20000,
    totalExigible: 285000,
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'TARIF_TLE_A',
    anneeScolaire: '2027-2028',
    niveau: 'Tle A',
    montantScolarite: 250000,
    fraisInscription: 40000,
    fraisAnnexes: 25000,
    totalExigible: 315000,
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'TARIF_TLE_D',
    anneeScolaire: '2027-2028',
    niveau: 'Tle D',
    montantScolarite: 260000,
    fraisInscription: 40000,
    fraisAnnexes: 25000,
    totalExigible: 325000,
    updatedAt: new Date().toISOString(),
  },

  // --- CYCLE TECHNIQUE & PROFESSIONNEL ---
  {
    id: 'TARIF_BEP_1',
    anneeScolaire: '2027-2028',
    niveau: 'BEP 1',
    montantScolarite: 200000,
    fraisInscription: 35000,
    fraisAnnexes: 30000, // Frais matériel d'atelier & blouses
    totalExigible: 265000,
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'TARIF_BEP_2',
    anneeScolaire: '2027-2028',
    niveau: 'BEP 2',
    montantScolarite: 210000,
    fraisInscription: 35000,
    fraisAnnexes: 30000,
    totalExigible: 275000,
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'TARIF_BAC_PRO_1',
    anneeScolaire: '2027-2028',
    niveau: 'Bac Pro 1',
    montantScolarite: 230000,
    fraisInscription: 40000,
    fraisAnnexes: 35000,
    totalExigible: 305000,
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'TARIF_BAC_PRO_2',
    anneeScolaire: '2027-2028',
    niveau: 'Bac Pro 2',
    montantScolarite: 245000,
    fraisInscription: 40000,
    fraisAnnexes: 35000,
    totalExigible: 320000,
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'TARIF_SERIE_C_PRIME',
    anneeScolaire: '2027-2028',
    niveau: "C'",
    montantScolarite: 255000,
    fraisInscription: 40000,
    fraisAnnexes: 35000,
    totalExigible: 330000,
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'TARIF_SERIE_D_PRIME',
    anneeScolaire: '2027-2028',
    niveau: "D'",
    montantScolarite: 265000,
    fraisInscription: 40000,
    fraisAnnexes: 35000,
    totalExigible: 340000,
    updatedAt: new Date().toISOString(),
  },
];


/* ============================================================================
   ARCHITECTURE DES DONNÉES
   ----------------------------------------------------------------------------
   SUPABASE est la source de vérité, partagée par toutes les interfaces.
   - Au démarrage : tout est chargé depuis Supabase (init()).
   - En continu   : Supabase Realtime pousse chaque changement (paiement, demande,
                    élève...) vers tous les navigateurs ouverts, sans recharger.
   - À l'écriture : mise à jour immédiate de l'écran + envoi ordonné vers Supabase
                    via SyncEngine (avec reprise automatique si le réseau coupe).
   - localStorage ne sert que de cliché pour l'affichage instantané / hors-ligne.
   ============================================================================ */

const CACHE_KEYS = {
  STUDENTS: 'edupay_cache_v6_eleves',
  ADMISSIONS: 'edupay_cache_v6_demandes',
  PAYMENTS: 'edupay_cache_v6_paiements',
  TARIFS: 'edupay_cache_v6_tarifs',
  SCHOOL: 'edupay_etablissement_supabase_v5',
};

// Anciennes clés (version "localStorage seul") : lues une fois pour récupérer d'éventuelles données.
const LEGACY_KEYS = {
  STUDENTS: 'edupay_eleves_supabase_v5',
  ADMISSIONS: 'edupay_admissions_supabase_v5',
  PAYMENTS: 'edupay_paiements_supabase_v5',
};
const LEGACY_DONE_KEY = 'edupay_legacy_migrated_v1';

type Listener = () => void;
const listeners = new Set<Listener>();

function notifyListeners() {
  listeners.forEach((cb) => cb());
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new Event('edupay_storage_change'));
  }
}

function readJson<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function writeJson(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* quota dépassé : le cliché local est facultatif */
  }
}

/** Données en mémoire (copie locale de la base). */
const cache = {
  students: [] as Student[], // inclut les élèves « radiés » (non affichés)
  admissions: [] as AdmissionRequest[],
  payments: [] as Payment[],
  tarifs: [] as TuitionTariff[],
};

if (typeof window !== 'undefined') {
  cache.students = readJson<Student[]>(CACHE_KEYS.STUDENTS, []);
  cache.admissions = readJson<AdmissionRequest[]>(CACHE_KEYS.ADMISSIONS, []);
  cache.payments = readJson<Payment[]>(CACHE_KEYS.PAYMENTS, []);
  cache.tarifs = readJson<TuitionTariff[]>(CACHE_KEYS.TARIFS, []);
}

function persistSnapshot() {
  writeJson(CACHE_KEYS.STUDENTS, cache.students);
  writeJson(CACHE_KEYS.ADMISSIONS, cache.admissions);
  writeJson(CACHE_KEYS.PAYMENTS, cache.payments);
  writeJson(CACHE_KEYS.TARIFS, cache.tarifs);
}

function changed() {
  persistSnapshot();
  notifyListeners();
}

const newId = (prefix: string) => `${prefix}_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;

function chunk<T>(arr: T[], size: number): T[][] {
  const out: T[][] = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}

/** Lit toute une table par pages de 1000 (limite par défaut de Supabase). */
async function fetchAll(table: string, orders: Array<{ col: string; asc: boolean }>): Promise<Row[]> {
  const rows: Row[] = [];
  const PAGE = 1000;
  for (let from = 0; ; from += PAGE) {
    let q = supabase.from(table).select('*');
    for (const o of orders) q = q.order(o.col, { ascending: o.asc });
    const { data, error } = await q.range(from, from + PAGE - 1);
    if (error) throw error;
    rows.push(...((data ?? []) as Row[]));
    if (!data || data.length < PAGE) break;
  }
  return rows;
}

/* ----- application d'une ligne Supabase sur la copie locale ----- */
function applyStudentRow(row: Row) {
  const incoming = studentFromRow(row);
  const i = cache.students.findIndex((s) => s.id === incoming.id);
  if (i === -1) {
    cache.students.unshift(incoming);
    return;
  }
  // Ligne d'écriture locale sans montants : on conserve ceux déjà connus.
  if (!('montant_paye' in row)) {
    incoming.montantPaye = cache.students[i].montantPaye;
    incoming.montantDonTotal = cache.students[i].montantDonTotal;
  }
  cache.students[i] = incoming;
}

function applyAdmissionRow(row: Row) {
  const incoming = admissionFromRow(row);
  const i = cache.admissions.findIndex((a) => a.id === incoming.id);
  if (i === -1) cache.admissions.unshift(incoming);
  else cache.admissions[i] = incoming;
}

function applyPaymentRow(row: Row) {
  const incoming = paymentFromRow(row);
  if (!cache.payments.some((p) => p.id === incoming.id)) cache.payments.unshift(incoming);
}

function applyTariffRow(row: Row) {
  const incoming = tariffFromRow(row);
  const i = cache.tarifs.findIndex(
    (t) => t.id === incoming.id || (t.anneeScolaire === incoming.anneeScolaire && t.niveau === incoming.niveau)
  );
  if (i === -1) cache.tarifs.push(incoming);
  else cache.tarifs[i] = { ...incoming, id: cache.tarifs[i].id };
}

/** Ré-applique par-dessus les données serveur les écritures pas encore envoyées. */
function overlayPending() {
  for (const op of SyncEngine.pendingOps()) {
    if (op.kind === 'upsert') {
      for (const row of op.rows) {
        if (op.table === 'eleves') applyStudentRow(row);
        else if (op.table === 'demandes_admission') applyAdmissionRow(row);
        else if (op.table === 'paiements') applyPaymentRow(row);
        else if (op.table === 'tarifs_scolarite') applyTariffRow(row);
      }
    } else if (op.table === 'eleves') {
      cache.students = cache.students.filter((s) => s.id !== op.match.id);
    } else if (op.table === 'tarifs_scolarite') {
      cache.tarifs = cache.tarifs.filter(
        (t) => !(t.anneeScolaire === op.match.annee_scolaire && t.niveau === op.match.niveau)
      );
    }
  }
}

function sortCache() {
  cache.students.sort((a, b) => (b.dateInscription || '').localeCompare(a.dateInscription || ''));
}

let initStarted = false;
let tarifRefetchTimer: ReturnType<typeof setTimeout> | null = null;

export class SchoolStore {
  /* ==========================================================================
     DÉMARRAGE, TEMPS RÉEL ET ÉTAT DE SYNCHRONISATION
     ========================================================================== */

  /** À appeler une fois au démarrage de l'application. */
  static async init() {
    if (initStarted || typeof window === 'undefined') return;
    initStarted = true;

    SyncEngine.onDiscard = () => void this.refetchAll();
    await this.refetchAll();
    this.startRealtime();

    // Filets de sécurité : on rattrape tout ce qu'on a pu manquer.
    const resync = () => {
      void SyncEngine.flush();
      void this.refetchAll();
    };
    window.addEventListener('online', resync);
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') resync();
    });
    setInterval(() => {
      if (document.visibilityState === 'visible') void this.refetchAll();
    }, 120000);
  }

  static getSyncStatus() {
    return SyncEngine.getStatus();
  }

  static subscribeSync(listener: Listener) {
    return SyncEngine.subscribe(listener);
  }

  static retrySync() {
    SyncEngine.retry();
  }

  static discardBlockedWrite() {
    SyncEngine.discardBlocked();
  }

  /** Recharge TOUT depuis Supabase (source de vérité). */
  static async refetchAll() {
    SyncEngine.patch({ loading: true });
    try {
      await SyncEngine.flush(); // envoyer d'abord ce qui est en attente
      const [eleves, paiements, demandes, tarifs] = await Promise.all([
        fetchAll('eleves', [
          { col: 'date_creation', asc: false },
          { col: 'id', asc: true },
        ]),
        fetchAll('paiements', [
          { col: 'date_paiement', asc: false },
          { col: 'id', asc: true },
        ]),
        fetchAll('demandes_admission', [
          { col: 'date_demande', asc: false },
          { col: 'id', asc: true },
        ]),
        fetchAll('tarifs_scolarite', [{ col: 'id', asc: true }]),
      ]);

      cache.students = eleves.map(studentFromRow);
      cache.payments = paiements.map(paymentFromRow);
      cache.admissions = demandes.map(admissionFromRow);
      cache.tarifs = tarifs.map(tariffFromRow);

      this.migrateLegacyLocalData();
      overlayPending();
      sortCache();
      changed();
      SyncEngine.patch({ hydrated: true, loading: false, offline: false });
    } catch (e) {
      const err = e as { code?: string; message?: string };
      console.error('[EduPay] Chargement Supabase impossible :', e);
      SyncEngine.patch({
        loading: false,
        ...(isTableMissingError(err)
          ? { error: 'Tables introuvables dans Supabase : exécutez le fichier schema.sql dans le SQL Editor.' }
          : err?.code === '42501'
            ? { error: 'Accès refusé par Supabase (RLS) : réexécutez schema.sql.' }
            : { offline: true }),
      });
    }
  }

  private static startRealtime() {
    const onRow =
      (table: 'eleves' | 'paiements' | 'demandes_admission') =>
      (payload: { eventType: string; new: Row; old: Row }) => {
        if (payload.eventType === 'DELETE') {
          const id = String(payload.old?.id ?? '');
          if (table === 'eleves') cache.students = cache.students.filter((s) => s.id !== id);
          if (table === 'paiements') cache.payments = cache.payments.filter((p) => p.id !== id);
          if (table === 'demandes_admission') cache.admissions = cache.admissions.filter((a) => a.id !== id);
        } else {
          if (table === 'eleves') applyStudentRow(payload.new);
          if (table === 'paiements') applyPaymentRow(payload.new);
          if (table === 'demandes_admission') applyAdmissionRow(payload.new);
        }
        changed();
      };

    let wasDown = false;
    supabase
      .channel('edupay-live')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'eleves' }, onRow('eleves'))
      .on('postgres_changes', { event: '*', schema: 'public', table: 'paiements' }, onRow('paiements'))
      .on('postgres_changes', { event: '*', schema: 'public', table: 'demandes_admission' }, onRow('demandes_admission'))
      .on('postgres_changes', { event: '*', schema: 'public', table: 'tarifs_scolarite' }, () => {
        // Petite table : on la recharge (les suppressions n'envoient que la clé).
        if (tarifRefetchTimer) clearTimeout(tarifRefetchTimer);
        tarifRefetchTimer = setTimeout(async () => {
          try {
            const rows = await fetchAll('tarifs_scolarite', [{ col: 'id', asc: true }]);
            cache.tarifs = rows.map(tariffFromRow);
            overlayPending();
            changed();
          } catch {
            /* le prochain rechargement complet rattrapera */
          }
        }, 300);
      })
      .subscribe((state) => {
        const live = state === 'SUBSCRIBED';
        SyncEngine.patch({ live });
        if (live && wasDown) void this.refetchAll(); // rattrapage après une coupure
        if (!live) wasDown = true;
      });
  }

  /**
   * Récupération UNIQUE des données restées dans le localStorage de l'ancienne version
   * (celles qui n'ont jamais atteint Supabase). On n'envoie que ce que la base ne connaît pas.
   */
  private static migrateLegacyLocalData() {
    try {
      if (localStorage.getItem(LEGACY_DONE_KEY)) return;
      const oldStudents = readJson<Student[]>(LEGACY_KEYS.STUDENTS, []);
      const oldAdmissions = readJson<AdmissionRequest[]>(LEGACY_KEYS.ADMISSIONS, []);
      const oldPayments = readJson<Payment[]>(LEGACY_KEYS.PAYMENTS, []);

      const knownStudentIds = new Set(cache.students.map((s) => s.id));
      const knownMatricules = new Set(cache.students.map((s) => s.matricule));
      const knownPaymentIds = new Set(cache.payments.map((p) => p.id));
      const knownRefs = new Set(cache.payments.map((p) => p.reference));
      const knownAdmissionIds = new Set(cache.admissions.map((a) => a.id));

      const newStudents = oldStudents.filter((s) => !knownStudentIds.has(s.id) && !knownMatricules.has(s.matricule));
      const newStudentIds = new Set(newStudents.map((s) => s.id));
      const pendingPayments = oldPayments.filter(
        (p) =>
          !knownPaymentIds.has(p.id) &&
          !knownRefs.has(p.reference) &&
          (knownStudentIds.has(p.studentId) || newStudentIds.has(p.studentId))
      );

      if (newStudents.length) {
        // Les montants des paiements seront recalculés par la base ; on ne garde ici que le solde « initial ».
        const rows = newStudents.map((s) => {
          const payeSurPaiements = pendingPayments
            .filter((p) => p.studentId === s.id)
            .reduce((t, p) => t + (p.montantScolarite || 0), 0);
          const donSurPaiements = pendingPayments
            .filter((p) => p.studentId === s.id)
            .reduce((t, p) => t + (p.montantDon || 0), 0);
          return studentToRow(
            {
              ...s,
              montantPaye: Math.max(0, (s.montantPaye || 0) - payeSurPaiements),
              montantDonTotal: Math.max(0, (s.montantDonTotal || 0) - donSurPaiements),
            },
            true
          );
        });
        for (const part of chunk(rows, 200)) {
          SyncEngine.enqueue({ kind: 'upsert', table: 'eleves', rows: part, onConflict: 'id' });
        }
      }
      const newAdmissions = oldAdmissions.filter((a) => !knownAdmissionIds.has(a.id));
      if (newAdmissions.length) {
        // Les demandes acceptées pointent vers un matricule : les élèves ci-dessus sont déjà en file avant.
        for (const part of chunk(newAdmissions.map(admissionToRow), 200)) {
          SyncEngine.enqueue({ kind: 'upsert', table: 'demandes_admission', rows: part, onConflict: 'id' });
        }
      }
      if (pendingPayments.length) {
        for (const part of chunk(pendingPayments.map(paymentToRow), 200)) {
          SyncEngine.enqueue({
            kind: 'upsert',
            table: 'paiements',
            rows: part,
            onConflict: 'id',
            ignoreDuplicates: true,
          });
        }
      }
      localStorage.setItem(LEGACY_DONE_KEY, '1');
    } catch (e) {
      console.warn('[EduPay] Récupération des anciennes données locales impossible :', e);
    }
  }

  /* ==========================================================================
     TARIFS DE SCOLARITÉ
     ========================================================================== */
  static getTarifs(annee: string = CURRENT_SCHOOL_YEAR): TuitionTariff[] {
    if (cache.tarifs.length > 0) return cache.tarifs.filter((t) => t.anneeScolaire === annee);
    return DEFAULT_TARIFS_2027_2028.filter((t) => t.anneeScolaire === annee);
  }

  static getAllTarifs(): TuitionTariff[] {
    return cache.tarifs.length > 0 ? [...cache.tarifs] : [...DEFAULT_TARIFS_2027_2028];
  }

  /** Remplace la grille (ex : « Restaurer la grille officielle ») et l'enregistre dans Supabase. */
  static saveTarifs(tarifs: TuitionTariff[]) {
    cache.tarifs = tarifs;
    changed();
    if (tarifs.length) {
      SyncEngine.enqueue({
        kind: 'upsert',
        table: 'tarifs_scolarite',
        rows: tarifs.map(tariffToRow),
        onConflict: 'annee_scolaire,niveau',
      });
    }
  }

  private static pushTariff(t: TuitionTariff) {
    SyncEngine.enqueue({
      kind: 'upsert',
      table: 'tarifs_scolarite',
      rows: [tariffToRow(t)],
      onConflict: 'annee_scolaire,niveau',
    });
  }

  static updateTariff(tariff: TuitionTariff) {
    const all = this.getAllTarifs();
    const index = all.findIndex(
      (t) => t.id === tariff.id || (t.anneeScolaire === tariff.anneeScolaire && t.niveau === tariff.niveau)
    );
    const totalExigible =
      Number(tariff.montantScolarite || 0) + Number(tariff.fraisInscription || 0) + Number(tariff.fraisAnnexes || 0);
    const updated: TuitionTariff = { ...tariff, totalExigible, updatedAt: new Date().toISOString() };

    if (index !== -1) all[index] = updated;
    else all.push(updated);
    cache.tarifs = all;
    changed();
    this.pushTariff(updated);
    return updated;
  }

  static addTariff(tariffData: Omit<TuitionTariff, 'id' | 'totalExigible' | 'updatedAt'>): TuitionTariff {
    const totalExigible =
      Number(tariffData.montantScolarite || 0) + Number(tariffData.fraisInscription || 0) + Number(tariffData.fraisAnnexes || 0);
    const newTariff: TuitionTariff = {
      ...tariffData,
      id: newId('TARIF'),
      totalExigible,
      updatedAt: new Date().toISOString(),
    };
    cache.tarifs = [...this.getAllTarifs(), newTariff];
    changed();
    this.pushTariff(newTariff);
    return newTariff;
  }

  static deleteTariff(tariffId: string): boolean {
    const all = this.getAllTarifs();
    const target = all.find((t) => t.id === tariffId);
    if (!target) return false;
    cache.tarifs = all.filter((t) => t.id !== tariffId);
    changed();
    SyncEngine.enqueue({
      kind: 'delete',
      table: 'tarifs_scolarite',
      match: { annee_scolaire: target.anneeScolaire, niveau: target.niveau },
    });
    return true;
  }

  static getTarifForClass(classe: string, annee: string = CURRENT_SCHOOL_YEAR): TuitionTariff | null {
    const tarifs = this.getTarifs(annee);
    const normalizedClass = classe.trim().toLowerCase();

    const directMatch = tarifs.find((t) => t.niveau.toLowerCase() === normalizedClass);
    if (directMatch) return directMatch;

    if (normalizedClass.includes("c'") || normalizedClass === "c'") {
      const cPrime = tarifs.find((t) => t.niveau === "C'");
      if (cPrime) return cPrime;
    }
    if (normalizedClass.includes("d'") || normalizedClass === "d'") {
      const dPrime = tarifs.find((t) => t.niveau === "D'");
      if (dPrime) return dPrime;
    }

    const prefixMatch = tarifs.find((t) => normalizedClass.startsWith(t.niveau.toLowerCase()));
    if (prefixMatch) return prefixMatch;

    return null;
  }

  /* ==========================================================================
     ÉLÈVES
     ========================================================================== */
  /** Élèves actifs (les élèves « radiés » sont conservés en base pour l'historique mais masqués). */
  static getStudents(): Student[] {
    return cache.students.filter((s) => s.statut !== 'radie');
  }

  private static pushStudent(s: Student, includeFinance: boolean) {
    SyncEngine.enqueue({
      kind: 'upsert',
      table: 'eleves',
      rows: [studentToRow(s, includeFinance)],
      onConflict: 'id',
    });
  }

  private static pushInscription(s: Student, annee: string = s.anneeScolaire) {
    SyncEngine.enqueue({
      kind: 'upsert',
      table: 'inscriptions_annuelles',
      rows: [
        {
          eleve_id: s.id,
          eleve_matricule: s.matricule,
          annee_scolaire: annee,
          classe: s.classe,
          scolarite_totale: s.scolariteTotale,
          montant_paye: s.montantPaye || 0,
          statut_reinscription: s.statutReinscription || 'REINSCRIT',
        },
      ],
      onConflict: 'eleve_id,annee_scolaire',
    });
  }

  /** Prochain matricule libre (plus grand numéro existant + 1, et non « nombre d'élèves + 1 »). */
  private static nextMatricule(): string {
    let max = 0;
    for (const s of cache.students) {
      const m = /^EDU-27-(\d+)$/.exec(s.matricule);
      if (m) max = Math.max(max, parseInt(m[1], 10));
    }
    return `EDU-27-${String(max + 1).padStart(4, '0')}`;
  }

  static addStudent(
    studentData: Omit<Student, 'id' | 'matricule' | 'montantPaye' | 'dateInscription' | 'statut' | 'anneeScolaire'> & {
      matricule?: string;
      montantPaye?: number;
      anneeScolaire?: string;
    }
  ): Student {
    const newStudent: Student = {
      ...studentData,
      id: newId('STU'),
      matricule: studentData.matricule || this.nextMatricule(),
      anneeScolaire: studentData.anneeScolaire || CURRENT_SCHOOL_YEAR,
      montantPaye: studentData.montantPaye || 0,
      montantDonTotal: studentData.montantDonTotal || 0,
      dateInscription: new Date().toISOString().split('T')[0],
      statut: 'inscrit',
      statutReinscription: studentData.statutReinscription || 'REINSCRIT',
    };

    cache.students.unshift(newStudent);
    changed();
    this.pushStudent(newStudent, true);
    this.pushInscription(newStudent);
    return newStudent;
  }

  static updateStudent(student: Student) {
    const i = cache.students.findIndex((s) => s.id === student.id);
    if (i === -1) return;
    cache.students[i] = student;
    changed();
    this.pushStudent(student, false); // les montants payés appartiennent à la base
  }

  static deleteStudent(studentId: string): boolean {
    const i = cache.students.findIndex((s) => s.id === studentId);
    if (i === -1) return false;
    const student = cache.students[i];
    const hasPayments = cache.payments.some((p) => p.studentId === studentId);

    if (hasPayments) {
      // L'historique financier ne doit jamais être perdu : l'élève est « radié », pas effacé.
      cache.students[i] = { ...student, statut: 'radie' };
      changed();
      this.pushStudent(cache.students[i], false);
    } else {
      cache.students.splice(i, 1);
      changed();
      SyncEngine.enqueue({ kind: 'delete', table: 'eleves', match: { id: studentId } });
    }
    return true;
  }

  static importStudentsBatch(
    records: Array<{
      matricule: string;
      nom: string;
      prenom: string;
      classeOrigine: string;
      statutFinAnnee: 'PASSANT' | 'REDOUBLANT';
      moyenneAnnuelle?: number;
      telephoneParent?: string;
      nomParent?: string;
      dateNaissance?: string;
    }>,
    anneeOrigine: string = PREVIOUS_SCHOOL_YEAR,
    anneeCible: string = CURRENT_SCHOOL_YEAR
  ): { created: number; updated: number; total: number } {
    const studentMap = new Map<string, Student>();
    cache.students.forEach((s) => studentMap.set(s.matricule.trim().toUpperCase(), s));

    const createdList: Student[] = [];
    const updatedList: Student[] = [];

    for (const row of records) {
      const cleanMatricule = row.matricule.trim().toUpperCase();
      if (!cleanMatricule) continue;

      const existing = studentMap.get(cleanMatricule);
      const classeProjetee = this.calculerClasseSuivante(row.classeOrigine, row.statutFinAnnee);
      const tarif = this.getTarifForClass(classeProjetee, anneeCible);
      const scolariteTotale = tarif ? tarif.totalExigible : 200000;

      if (existing) {
        existing.anneeOrigine = anneeOrigine;
        existing.classePrecedente = row.classeOrigine;
        existing.statutFinAnnee = row.statutFinAnnee;
        existing.moyenneAnnuelle = row.moyenneAnnuelle || existing.moyenneAnnuelle;
        if (row.telephoneParent) existing.telephoneParent = row.telephoneParent;
        if (row.nomParent) existing.nomParent = row.nomParent;
        existing.statutReinscription = existing.statutReinscription || 'EN_ATTENTE_REINSCRIPTION';
        if (!updatedList.includes(existing) && !createdList.includes(existing)) updatedList.push(existing);
      } else {
        const newStudent: Student = {
          id: newId('STU_IMP'),
          matricule: cleanMatricule,
          nom: row.nom.trim().toUpperCase(),
          prenom: row.prenom.trim(),
          dateNaissance: row.dateNaissance || '2012-01-01',
          classe: classeProjetee,
          classePrecedente: row.classeOrigine,
          anneeScolaire: anneeCible,
          anneeOrigine,
          statutFinAnnee: row.statutFinAnnee,
          statutReinscription: 'EN_ATTENTE_REINSCRIPTION',
          scolariteTotale,
          montantPaye: 0,
          montantDonTotal: 0,
          nomParent: row.nomParent || 'Parent ' + row.nom.toUpperCase(),
          telephoneParent: row.telephoneParent || '70000000',
          moyenneAnnuelle: row.moyenneAnnuelle,
          dateInscription: new Date().toISOString().split('T')[0],
          statut: 'inscrit',
        };
        studentMap.set(cleanMatricule, newStudent);
        createdList.push(newStudent);
      }
    }

    cache.students = Array.from(studentMap.values());
    sortCache();
    changed();

    // Deux lots distincts : les nouveaux (avec montants) et les existants (sans toucher aux montants).
    for (const part of chunk(createdList.map((s) => studentToRow(s, true)), 200)) {
      SyncEngine.enqueue({ kind: 'upsert', table: 'eleves', rows: part, onConflict: 'id' });
    }
    for (const part of chunk(updatedList.map((s) => studentToRow(s, false)), 200)) {
      SyncEngine.enqueue({ kind: 'upsert', table: 'eleves', rows: part, onConflict: 'id' });
    }

    return { created: createdList.length, updated: updatedList.length, total: records.length };
  }

  static reenrollStudent(
    studentId: string,
    nouvelleClasse: string,
    nouvelleScolariteTotale: number,
    options?: { telephoneParent?: string; nomParent?: string }
  ): Student | null {
    const student = cache.students.find((s) => s.id === studentId);
    if (!student) return null;

    student.classe = nouvelleClasse;
    student.anneeScolaire = CURRENT_SCHOOL_YEAR;
    student.scolariteTotale = nouvelleScolariteTotale;
    student.statutReinscription = 'REINSCRIT';
    student.dateInscription = new Date().toISOString().split('T')[0];
    if (options?.telephoneParent) student.telephoneParent = options.telephoneParent;
    if (options?.nomParent) student.nomParent = options.nomParent;

    changed();
    this.pushStudent(student, false);
    this.pushInscription(student, CURRENT_SCHOOL_YEAR);
    return student;
  }

  static calculerClasseSuivante(classeActuelle: string, decision: 'PASSANT' | 'REDOUBLANT'): string {
    if (decision === 'REDOUBLANT') return classeActuelle;

    const cycleProgression: Record<string, string> = {
      '6ème': '5ème',
      '5ème': '4ème',
      '4ème': '3ème',
      '3ème': '2nde A',
      '2nde A': '1ère A',
      '2nde C': '1ère D',
      '1ère A': 'Tle A',
      '1ère D': 'Tle D',
      'BEP 1': 'BEP 2',
      'BEP 2': 'Bac Pro 1',
      'Bac Pro 1': 'Bac Pro 2',
      "C'": "D'",
    };

    const clean = classeActuelle.trim();
    for (const [curr, next] of Object.entries(cycleProgression)) {
      if (clean.toLowerCase().startsWith(curr.toLowerCase())) return next;
    }
    return classeActuelle;
  }

  /* ==========================================================================
     PAIEMENTS
     ========================================================================== */
  static getPayments(): Payment[] {
    return cache.payments;
  }

  /**
   * Enregistre un paiement. Le solde de l'élève est recalculé par la BASE (trigger SQL) :
   * l'écran est mis à jour tout de suite ici, puis confirmé par le temps réel.
   */
  static addPayment(payment: Payment) {
    if (!cache.payments.some((p) => p.id === payment.id)) cache.payments.unshift(payment);

    const student = cache.students.find((s) => s.id === payment.studentId);
    if (student) {
      student.montantPaye = (student.montantPaye || 0) + payment.montantScolarite;
      student.montantDonTotal = (student.montantDonTotal || 0) + (payment.montantDon || 0);
    }
    changed();

    SyncEngine.enqueue({
      kind: 'upsert',
      table: 'paiements',
      rows: [paymentToRow(payment)],
      onConflict: 'id',
      ignoreDuplicates: true, // un renvoi après coupure ne peut jamais compter le paiement deux fois
    });
  }

  /* ==========================================================================
     DEMANDES D'ADMISSION
     ========================================================================== */
  static getAdmissions(): AdmissionRequest[] {
    return cache.admissions;
  }

  private static pushAdmission(a: AdmissionRequest) {
    SyncEngine.enqueue({ kind: 'upsert', table: 'demandes_admission', rows: [admissionToRow(a)], onConflict: 'id' });
  }

  static addAdmissionRequest(
    request: Omit<AdmissionRequest, 'id' | 'dateDemande' | 'statut' | 'anneeScolaire'> & { anneeScolaire?: string }
  ): AdmissionRequest {
    const newReq: AdmissionRequest = {
      ...request,
      id: newId('ADM'),
      dateDemande: new Date().toISOString(),
      statut: 'en_attente',
      anneeScolaire: request.anneeScolaire || CURRENT_SCHOOL_YEAR,
    };
    cache.admissions.unshift(newReq);
    changed();
    this.pushAdmission(newReq);
    return newReq;
  }

  static acceptAdmission(requestId: string, customScolarite?: number): Student | null {
    const req = cache.admissions.find((a) => a.id === requestId);
    if (!req) return null;

    const tarif = this.getTarifForClass(req.classeDemandee, req.anneeScolaire || CURRENT_SCHOOL_YEAR);
    const scolariteTotale = customScolarite !== undefined ? customScolarite : tarif ? tarif.totalExigible : 200000;

    // L'élève est mis en file AVANT la demande (la demande référence son matricule).
    const student = this.addStudent({
      nom: req.nomEnfant.toUpperCase(),
      prenom: req.prenomEnfant,
      dateNaissance: req.dateNaissance,
      classe: req.classeDemandee,
      anneeScolaire: req.anneeScolaire || CURRENT_SCHOOL_YEAR,
      scolariteTotale,
      nomParent: req.nomParent,
      telephoneParent: req.telephoneParent,
      emailParent: req.emailParent,
      adresse: req.adresse,
      montantPaye: 0,
      montantDonTotal: req.montantDon || 0,
      etablissementOrigine: req.etablissementOrigine,
      decisionBulletin: req.decisionBulletin,
      moyenneAnnuelle: req.moyenneAnnuelle,
      motifVenue: req.motifVenue,
      descriptionVenue: req.descriptionVenue,
      bulletinNomFichier: req.bulletinNomFichier,
      statutReinscription: 'REINSCRIT',
    });

    req.statut = 'accepte';
    req.matriculeAttribue = student.matricule;
    changed();
    this.pushAdmission(req);
    return student;
  }

  static rejectAdmission(requestId: string, motif?: string) {
    const req = cache.admissions.find((a) => a.id === requestId);
    if (!req) return;
    req.statut = 'refuse';
    req.motifRefus = motif || 'Places indisponibles ou dossier non retenu.';
    changed();
    this.pushAdmission(req);
  }

  /* ==========================================================================
     DIVERS
     ========================================================================== */
  static getSchoolInfo(): SchoolInfo {
    if (typeof window === 'undefined') return DEFAULT_SCHOOL_INFO;
    return readJson<SchoolInfo>(CACHE_KEYS.SCHOOL, DEFAULT_SCHOOL_INFO);
  }

  static subscribe(listener: Listener) {
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  }
}
