import type {
  AdmissionRequest,
  Payment,
  Student,
  TuitionTariff,
} from '../types';

/* Convertisseurs entre les objets de l'application (camelCase) et les lignes
   des tables Supabase (snake_case, en français). */

export type Row = Record<string, unknown>;

const str = (v: unknown): string | undefined => (v === null || v === undefined || v === '' ? undefined : String(v));
const num = (v: unknown): number | undefined => (v === null || v === undefined || v === '' ? undefined : Number(v));
/** Chaîne vide -> null (une colonne DATE refuse ''). */
const nn = <T>(v: T | '' | undefined): T | null => (v === '' || v === undefined ? null : v);

/* ---------------------------------- ÉLÈVES --------------------------------- */
export function studentFromRow(r: Row): Student {
  return {
    id: String(r.id),
    matricule: String(r.matricule),
    nom: String(r.nom ?? ''),
    prenom: String(r.prenom ?? ''),
    dateNaissance: str(r.date_naissance) ?? '',
    classe: String(r.classe ?? ''),
    anneeScolaire: String(r.annee_scolaire ?? ''),
    scolariteTotale: Number(r.scolarite_totale ?? 0),
    montantPaye: Number(r.montant_paye ?? 0),
    montantDonTotal: Number(r.montant_don_total ?? 0),
    nomParent: String(r.nom_parent ?? ''),
    telephoneParent: String(r.telephone_parent ?? ''),
    emailParent: str(r.email_parent),
    adresse: str(r.adresse_domicile),
    dateInscription: (str(r.date_inscription) ?? '').slice(0, 10),
    statut: r.statut_inscription === 'radie' ? 'radie' : 'inscrit',
    etablissementOrigine: str(r.etablissement_origine),
    decisionBulletin: str(r.decision_bulletin) as Student['decisionBulletin'],
    moyenneAnnuelle: num(r.moyenne_annuelle),
    motifVenue: str(r.motif_venue) as Student['motifVenue'],
    descriptionVenue: str(r.description_motif),
    bulletinNomFichier: str(r.bulletin_nom_fichier),
    anneeOrigine: str(r.annee_origine),
    classePrecedente: str(r.classe_precedente),
    statutFinAnnee: str(r.statut_fin_annee) as Student['statutFinAnnee'],
    statutReinscription: str(r.statut_reinscription) as Student['statutReinscription'],
  };
}

/**
 * Les montants payés (montant_paye / montant_don_total) sont calculés par la base
 * (trigger sur `paiements`). On ne les envoie qu'à la CRÉATION d'un élève, jamais
 * lors d'une modification, pour ne pas écraser un paiement arrivé entre-temps.
 */
export function studentToRow(s: Student, includeFinance: boolean): Row {
  const row: Row = {
    id: s.id,
    matricule: s.matricule,
    nom: s.nom,
    prenom: s.prenom,
    date_naissance: nn(s.dateNaissance),
    classe: s.classe,
    annee_scolaire: s.anneeScolaire,
    scolarite_totale: s.scolariteTotale,
    nom_parent: s.nomParent,
    telephone_parent: s.telephoneParent,
    email_parent: nn(s.emailParent),
    adresse_domicile: nn(s.adresse),
    annee_origine: nn(s.anneeOrigine),
    classe_precedente: nn(s.classePrecedente),
    statut_fin_annee: nn(s.statutFinAnnee),
    statut_reinscription: s.statutReinscription ?? 'REINSCRIT',
    decision_bulletin: s.decisionBulletin ?? 'PASSAGE',
    moyenne_annuelle: nn(s.moyenneAnnuelle),
    etablissement_origine: nn(s.etablissementOrigine),
    motif_venue: nn(s.motifVenue),
    description_motif: nn(s.descriptionVenue),
    bulletin_nom_fichier: nn(s.bulletinNomFichier),
    statut_inscription: s.statut,
    date_inscription: nn(s.dateInscription) ?? new Date().toISOString().slice(0, 10),
    date_modification: new Date().toISOString(),
  };
  if (includeFinance) {
    row.montant_paye = s.montantPaye || 0;
    row.montant_don_total = s.montantDonTotal || 0;
  }
  return row;
}

/* ------------------------------ DEMANDES D'ADMISSION ------------------------ */
const ADM_STATUT_FROM: Record<string, AdmissionRequest['statut']> = {
  EN_ATTENTE: 'en_attente',
  ACCEPTE: 'accepte',
  REFUSE: 'refuse',
};
const ADM_STATUT_TO: Record<AdmissionRequest['statut'], string> = {
  en_attente: 'EN_ATTENTE',
  accepte: 'ACCEPTE',
  refuse: 'REFUSE',
};

export function admissionFromRow(r: Row): AdmissionRequest {
  return {
    id: String(r.id),
    dateDemande: String(r.date_demande ?? new Date().toISOString()),
    nomEnfant: String(r.nom_enfant ?? ''),
    prenomEnfant: String(r.prenom_enfant ?? ''),
    dateNaissance: str(r.date_naissance) ?? '',
    classeDemandee: String(r.classe_demandee ?? ''),
    anneeScolaire: String(r.annee_scolaire ?? ''),
    nomParent: String(r.nom_parent ?? ''),
    telephoneParent: String(r.telephone_parent ?? ''),
    emailParent: str(r.email_parent),
    adresse: str(r.adresse_domicile) ?? '',
    statut: ADM_STATUT_FROM[String(r.statut_admission)] ?? 'en_attente',
    matriculeAttribue: str(r.matricule_attribue),
    notes: str(r.observations_secretaire),
    motifRefus: str(r.motif_refus),
    estNouveauTransfert: r.est_nouvel_eleve !== false,
    etablissementOrigine: str(r.etablissement_origine),
    decisionBulletin: (str(r.decision_bulletin) ?? 'PASSAGE') as AdmissionRequest['decisionBulletin'],
    moyenneAnnuelle: num(r.moyenne_annuelle),
    motifVenue: str(r.motif_venue) as AdmissionRequest['motifVenue'],
    descriptionVenue: str(r.description_motif),
    bulletinNomFichier: str(r.bulletin_nom_fichier),
    montantDon: Number(r.montant_don ?? 0),
  };
}

export function admissionToRow(a: AdmissionRequest): Row {
  return {
    id: a.id,
    date_demande: a.dateDemande,
    annee_scolaire: a.anneeScolaire,
    nom_enfant: a.nomEnfant,
    prenom_enfant: a.prenomEnfant,
    date_naissance: nn(a.dateNaissance),
    classe_demandee: a.classeDemandee,
    nom_parent: a.nomParent,
    telephone_parent: a.telephoneParent,
    email_parent: nn(a.emailParent),
    adresse_domicile: nn(a.adresse),
    est_nouvel_eleve: a.estNouveauTransfert,
    etablissement_origine: nn(a.etablissementOrigine),
    decision_bulletin: a.decisionBulletin ?? 'PASSAGE',
    moyenne_annuelle: nn(a.moyenneAnnuelle),
    motif_venue: nn(a.motifVenue),
    description_motif: a.descriptionVenue ?? '',
    bulletin_nom_fichier: nn(a.bulletinNomFichier),
    montant_don: a.montantDon || 0,
    statut_admission: ADM_STATUT_TO[a.statut],
    matricule_attribue: nn(a.matriculeAttribue),
    observations_secretaire: nn(a.notes),
    motif_refus: nn(a.motifRefus),
    date_traitement: a.statut === 'en_attente' ? null : new Date().toISOString(),
  };
}

/* ---------------------------------- PAIEMENTS ------------------------------- */
export function paymentFromRow(r: Row): Payment {
  return {
    id: String(r.id),
    reference: String(r.reference_quittance),
    studentId: String(r.eleve_id),
    studentMatricule: String(r.eleve_matricule ?? ''),
    studentNom: String(r.nom_eleve ?? ''),
    studentClasse: String(r.classe_eleve ?? ''),
    anneeScolaire: str(r.annee_scolaire),
    montant: Number(r.montant_total ?? 0),
    montantScolarite: Number(r.montant_scolarite ?? 0),
    montantDon: Number(r.montant_don ?? 0),
    mode: String(r.mode_paiement) as Payment['mode'],
    telephonePayeur: str(r.telephone_payeur),
    nomPayeur: String(r.nom_payeur ?? ''),
    statut: String(r.statut_paiement ?? 'SUCCES') as Payment['statut'],
    encaissePar: String(r.encaisse_par) as Payment['encaissePar'],
    agentNom: str(r.nom_agent),
    date: String(r.date_paiement ?? new Date().toISOString()),
    notes: str(r.observations),
  };
}

export function paymentToRow(p: Payment): Row {
  return {
    id: p.id,
    reference_quittance: p.reference,
    annee_scolaire: p.anneeScolaire || '2027-2028',
    eleve_id: p.studentId,
    eleve_matricule: p.studentMatricule,
    nom_eleve: p.studentNom,
    classe_eleve: p.studentClasse,
    montant_total: p.montant,
    montant_scolarite: p.montantScolarite || 0,
    montant_don: p.montantDon || 0,
    mode_paiement: p.mode,
    encaisse_par: p.encaissePar,
    statut_paiement: p.statut,
    nom_payeur: p.nomPayeur,
    telephone_payeur: nn(p.telephonePayeur),
    nom_agent: nn(p.agentNom),
    observations: nn(p.notes),
    date_paiement: p.date,
  };
}

/* ----------------------------------- TARIFS --------------------------------- */
export function tariffFromRow(r: Row): TuitionTariff {
  const montant = Number(r.montant_scolarite ?? 0);
  const insc = Number(r.frais_inscription ?? 0);
  const annexes = Number(r.frais_annexes ?? 0);
  return {
    id: String(r.id ?? `${r.annee_scolaire}|${r.niveau}`),
    anneeScolaire: String(r.annee_scolaire),
    niveau: String(r.niveau),
    montantScolarite: montant,
    fraisInscription: insc,
    fraisAnnexes: annexes,
    totalExigible: num(r.total_exigible) ?? montant + insc + annexes,
    updatedAt: String(r.updated_at ?? new Date().toISOString()),
  };
}

/** `total_exigible` est une colonne générée par la base : on ne l'envoie pas. */
export function tariffToRow(t: TuitionTariff): Row {
  return {
    annee_scolaire: t.anneeScolaire,
    niveau: t.niveau,
    montant_scolarite: t.montantScolarite,
    frais_inscription: t.fraisInscription,
    frais_annexes: t.fraisAnnexes,
    updated_at: new Date().toISOString(),
  };
}
