-- ============================================================================
-- EDUPAY SCOLARITÉ — BASE DE DONNÉES SUPABASE (PostgreSQL) — 100 % en français
-- ----------------------------------------------------------------------------
-- Ce script est SÛR À RÉEXÉCUTER : il ne supprime aucune table ni aucune donnée.
-- Il crée ce qui manque, ajoute les colonnes manquantes, installe le calcul
-- automatique des soldes et active le TEMPS RÉEL entre les interfaces.
--
-- Où l'exécuter : Supabase > votre projet > SQL Editor > New query > Run
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. TYPES ÉNUMÉRÉS (créés seulement s'ils n'existent pas)
-- ----------------------------------------------------------------------------
DO $$ BEGIN
  CREATE TYPE type_mode_paiement AS ENUM ('ORANGE_MONEY','MOOV_MONEY','MTN_MONEY','LIGDICASH','ESPECES_GUICHET');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE type_statut_paiement AS ENUM ('SUCCES','EN_COURS','ECHOUE');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE type_statut_admission AS ENUM ('EN_ATTENTE','ACCEPTE','REFUSE');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE type_canal_encaissement AS ENUM ('PARENT_EN_LIGNE','SECRETAIRE_GUICHET');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE type_decision_bulletin AS ENUM ('PASSAGE','REDOUBLEMENT','NOUVEAU_CYCLE');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE type_statut_fin_annee AS ENUM ('PASSANT','REDOUBLANT');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE type_statut_reinscription AS ENUM ('EN_ATTENTE_REINSCRIPTION','REINSCRIT','TRANSFERE','ABANDON');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- ----------------------------------------------------------------------------
-- 2. TABLES
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS utilisateurs (
  id SERIAL PRIMARY KEY,
  nom_complet VARCHAR(150) NOT NULL,
  email VARCHAR(150) UNIQUE NOT NULL,
  code_pin VARCHAR(50) NOT NULL DEFAULT '1234',
  role_utilisateur VARCHAR(50) NOT NULL DEFAULT 'SECRETAIRE',
  telephone VARCHAR(50),
  est_actif BOOLEAN NOT NULL DEFAULT TRUE,
  date_derniere_connexion TIMESTAMPTZ,
  date_creation TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS tarifs_scolarite (
  id SERIAL PRIMARY KEY,
  annee_scolaire VARCHAR(20) NOT NULL,
  niveau VARCHAR(50) NOT NULL,
  montant_scolarite NUMERIC(12,2) NOT NULL CHECK (montant_scolarite >= 0),
  frais_inscription NUMERIC(12,2) NOT NULL DEFAULT 0 CHECK (frais_inscription >= 0),
  frais_annexes NUMERIC(12,2) NOT NULL DEFAULT 0 CHECK (frais_annexes >= 0),
  total_exigible NUMERIC(12,2) GENERATED ALWAYS AS (montant_scolarite + frais_inscription + frais_annexes) STORED,
  date_creation TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT uq_tarifs_annee_niveau UNIQUE (annee_scolaire, niveau)
);

CREATE TABLE IF NOT EXISTS eleves (
  id VARCHAR(50) PRIMARY KEY,
  matricule VARCHAR(50) UNIQUE NOT NULL,
  nom VARCHAR(100) NOT NULL,
  prenom VARCHAR(100) NOT NULL,
  sexe VARCHAR(10),
  date_naissance DATE,
  classe VARCHAR(50) NOT NULL,
  annee_scolaire VARCHAR(20) NOT NULL DEFAULT '2027-2028',
  scolarite_totale NUMERIC(12,2) NOT NULL DEFAULT 200000,
  montant_paye NUMERIC(12,2) NOT NULL DEFAULT 0,
  montant_don_total NUMERIC(12,2) NOT NULL DEFAULT 0,
  nom_parent VARCHAR(150) NOT NULL,
  telephone_parent VARCHAR(50) NOT NULL,
  email_parent VARCHAR(150),
  adresse_domicile TEXT,
  annee_origine VARCHAR(20),
  classe_precedente VARCHAR(50),
  statut_fin_annee type_statut_fin_annee,
  statut_reinscription type_statut_reinscription DEFAULT 'REINSCRIT',
  decision_bulletin type_decision_bulletin DEFAULT 'PASSAGE',
  moyenne_annuelle NUMERIC(4,2),
  etablissement_origine VARCHAR(255),
  motif_venue VARCHAR(100),
  description_motif TEXT,
  bulletin_nom_fichier VARCHAR(255),
  statut_inscription VARCHAR(20) NOT NULL DEFAULT 'inscrit',
  date_inscription DATE NOT NULL DEFAULT CURRENT_DATE,
  date_creation TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  date_modification TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS inscriptions_annuelles (
  id SERIAL PRIMARY KEY,
  eleve_id VARCHAR(50) NOT NULL REFERENCES eleves(id) ON DELETE CASCADE,
  eleve_matricule VARCHAR(50) NOT NULL,
  annee_scolaire VARCHAR(20) NOT NULL,
  classe VARCHAR(50) NOT NULL,
  scolarite_totale NUMERIC(12,2) NOT NULL,
  montant_paye NUMERIC(12,2) NOT NULL DEFAULT 0,
  statut_reinscription type_statut_reinscription NOT NULL DEFAULT 'REINSCRIT',
  date_validation TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  valide_par_utilisateur_id INT REFERENCES utilisateurs(id) ON DELETE SET NULL,
  CONSTRAINT uq_inscription_eleve_annee UNIQUE (eleve_id, annee_scolaire)
);

CREATE TABLE IF NOT EXISTS demandes_admission (
  id VARCHAR(50) PRIMARY KEY,
  date_demande TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  annee_scolaire VARCHAR(20) NOT NULL DEFAULT '2027-2028',
  nom_enfant VARCHAR(100) NOT NULL,
  prenom_enfant VARCHAR(100) NOT NULL,
  date_naissance DATE,
  classe_demandee VARCHAR(50) NOT NULL,
  nom_parent VARCHAR(150) NOT NULL,
  telephone_parent VARCHAR(50) NOT NULL,
  email_parent VARCHAR(150),
  adresse_domicile TEXT,
  est_nouvel_eleve BOOLEAN NOT NULL DEFAULT TRUE,
  etablissement_origine VARCHAR(255),
  decision_bulletin type_decision_bulletin NOT NULL DEFAULT 'PASSAGE',
  moyenne_annuelle NUMERIC(4,2),
  motif_venue VARCHAR(100),
  description_motif TEXT NOT NULL DEFAULT '',
  bulletin_nom_fichier VARCHAR(255),
  montant_don NUMERIC(12,2) NOT NULL DEFAULT 0,
  statut_admission type_statut_admission NOT NULL DEFAULT 'EN_ATTENTE',
  matricule_attribue VARCHAR(50) REFERENCES eleves(matricule) ON DELETE SET NULL,
  observations_secretaire TEXT,
  motif_refus TEXT,
  date_traitement TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS paiements (
  id VARCHAR(50) PRIMARY KEY,
  reference_quittance VARCHAR(100) UNIQUE NOT NULL,
  annee_scolaire VARCHAR(20) NOT NULL DEFAULT '2027-2028',
  eleve_id VARCHAR(50) NOT NULL REFERENCES eleves(id) ON DELETE RESTRICT,
  eleve_matricule VARCHAR(50) NOT NULL,
  nom_eleve VARCHAR(200) NOT NULL,
  classe_eleve VARCHAR(50) NOT NULL,
  montant_total NUMERIC(12,2) NOT NULL CHECK (montant_total > 0),
  montant_scolarite NUMERIC(12,2) NOT NULL DEFAULT 0,
  montant_don NUMERIC(12,2) NOT NULL DEFAULT 0,
  mode_paiement type_mode_paiement NOT NULL,
  encaisse_par type_canal_encaissement NOT NULL,
  statut_paiement type_statut_paiement NOT NULL DEFAULT 'SUCCES',
  code_validation_otp VARCHAR(20),
  nom_payeur VARCHAR(150) NOT NULL,
  telephone_payeur VARCHAR(50),
  utilisateur_id INT REFERENCES utilisateurs(id) ON DELETE SET NULL,
  nom_agent VARCHAR(150),
  observations TEXT,
  date_paiement TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- ----------------------------------------------------------------------------
-- 3. MISE À NIVEAU SI VOS TABLES EXISTAIENT DÉJÀ DANS UNE ANCIENNE VERSION
--    (ajoute uniquement les colonnes manquantes — aucune donnée touchée)
-- ----------------------------------------------------------------------------
ALTER TABLE eleves ADD COLUMN IF NOT EXISTS annee_scolaire VARCHAR(20) NOT NULL DEFAULT '2027-2028';
ALTER TABLE eleves ADD COLUMN IF NOT EXISTS montant_don_total NUMERIC(12,2) NOT NULL DEFAULT 0;
ALTER TABLE eleves ADD COLUMN IF NOT EXISTS annee_origine VARCHAR(20);
ALTER TABLE eleves ADD COLUMN IF NOT EXISTS classe_precedente VARCHAR(50);
ALTER TABLE eleves ADD COLUMN IF NOT EXISTS statut_fin_annee type_statut_fin_annee;
ALTER TABLE eleves ADD COLUMN IF NOT EXISTS statut_reinscription type_statut_reinscription DEFAULT 'REINSCRIT';
ALTER TABLE eleves ADD COLUMN IF NOT EXISTS decision_bulletin type_decision_bulletin DEFAULT 'PASSAGE';
ALTER TABLE eleves ADD COLUMN IF NOT EXISTS moyenne_annuelle NUMERIC(4,2);
ALTER TABLE eleves ADD COLUMN IF NOT EXISTS etablissement_origine VARCHAR(255);
ALTER TABLE eleves ADD COLUMN IF NOT EXISTS motif_venue VARCHAR(100);
ALTER TABLE eleves ADD COLUMN IF NOT EXISTS description_motif TEXT;
ALTER TABLE eleves ADD COLUMN IF NOT EXISTS bulletin_nom_fichier VARCHAR(255);
ALTER TABLE eleves ADD COLUMN IF NOT EXISTS adresse_domicile TEXT;
ALTER TABLE eleves ADD COLUMN IF NOT EXISTS statut_inscription VARCHAR(20) NOT NULL DEFAULT 'inscrit';

ALTER TABLE demandes_admission ADD COLUMN IF NOT EXISTS annee_scolaire VARCHAR(20) NOT NULL DEFAULT '2027-2028';
ALTER TABLE demandes_admission ADD COLUMN IF NOT EXISTS adresse_domicile TEXT;
ALTER TABLE demandes_admission ADD COLUMN IF NOT EXISTS observations_secretaire TEXT;
ALTER TABLE demandes_admission ADD COLUMN IF NOT EXISTS date_traitement TIMESTAMPTZ;
ALTER TABLE demandes_admission ALTER COLUMN description_motif SET DEFAULT '';

ALTER TABLE paiements ADD COLUMN IF NOT EXISTS annee_scolaire VARCHAR(20) NOT NULL DEFAULT '2027-2028';
ALTER TABLE paiements ADD COLUMN IF NOT EXISTS code_validation_otp VARCHAR(20);
ALTER TABLE paiements ADD COLUMN IF NOT EXISTS utilisateur_id INT REFERENCES utilisateurs(id) ON DELETE SET NULL;

-- L'historique des paiements ne doit JAMAIS disparaître avec un élève supprimé.
DO $$ BEGIN
  ALTER TABLE paiements DROP CONSTRAINT IF EXISTS paiements_eleve_id_fkey;
  ALTER TABLE paiements ADD CONSTRAINT paiements_eleve_id_fkey
    FOREIGN KEY (eleve_id) REFERENCES eleves(id) ON DELETE RESTRICT;
EXCEPTION WHEN others THEN NULL; END $$;

-- ----------------------------------------------------------------------------
-- 4. INDEX
-- ----------------------------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_eleves_classe_annee ON eleves(classe, annee_scolaire);
CREATE INDEX IF NOT EXISTS idx_eleves_telephone ON eleves(telephone_parent);
CREATE INDEX IF NOT EXISTS idx_demandes_statut ON demandes_admission(statut_admission);
CREATE INDEX IF NOT EXISTS idx_demandes_date ON demandes_admission(date_demande);
CREATE INDEX IF NOT EXISTS idx_paiements_eleve_id ON paiements(eleve_id);
CREATE INDEX IF NOT EXISTS idx_paiements_date ON paiements(date_paiement);

-- ----------------------------------------------------------------------------
-- 5. CALCUL AUTOMATIQUE DES SOLDES (côté base, donc fiable même si deux
--    personnes encaissent en même temps : plus de "dernier qui écrase l'autre")
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_appliquer_paiement() RETURNS TRIGGER AS $$
BEGIN
  IF NEW.statut_paiement = 'SUCCES' THEN
    UPDATE eleves
       SET montant_paye      = montant_paye + COALESCE(NEW.montant_scolarite, 0),
           montant_don_total = montant_don_total + COALESCE(NEW.montant_don, 0),
           date_modification = CURRENT_TIMESTAMP
     WHERE id = NEW.eleve_id;

    UPDATE inscriptions_annuelles
       SET montant_paye = montant_paye + COALESCE(NEW.montant_scolarite, 0)
     WHERE eleve_id = NEW.eleve_id AND annee_scolaire = NEW.annee_scolaire;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_appliquer_paiement ON paiements;
CREATE TRIGGER trg_appliquer_paiement
AFTER INSERT ON paiements
FOR EACH ROW EXECUTE FUNCTION fn_appliquer_paiement();

-- ----------------------------------------------------------------------------
-- 6. GRILLE TARIFAIRE PAR DÉFAUT (n'écrase JAMAIS vos modifications)
-- ----------------------------------------------------------------------------
INSERT INTO tarifs_scolarite (annee_scolaire, niveau, montant_scolarite, frais_inscription, frais_annexes) VALUES
  ('2027-2028','6ème',160000,25000,15000), ('2027-2028','5ème',160000,25000,15000),
  ('2027-2028','4ème',175000,25000,15000), ('2027-2028','3ème',190000,30000,20000),
  ('2027-2028','2nde A',210000,30000,20000), ('2027-2028','2nde C',215000,30000,20000),
  ('2027-2028','1ère A',225000,35000,20000), ('2027-2028','1ère D',230000,35000,20000),
  ('2027-2028','Tle A',250000,40000,25000), ('2027-2028','Tle D',260000,40000,25000),
  ('2027-2028','BEP 1',200000,35000,30000), ('2027-2028','BEP 2',210000,35000,30000),
  ('2027-2028','Bac Pro 1',230000,40000,35000), ('2027-2028','Bac Pro 2',245000,40000,35000),
  ('2027-2028','C''',255000,40000,35000), ('2027-2028','D''',265000,40000,35000)
ON CONFLICT (annee_scolaire, niveau) DO NOTHING;

-- ----------------------------------------------------------------------------
-- 7. ACCÈS API (RLS) — nécessaire pour que le site puisse lire/écrire
-- ----------------------------------------------------------------------------
ALTER TABLE utilisateurs ENABLE ROW LEVEL SECURITY;
ALTER TABLE tarifs_scolarite ENABLE ROW LEVEL SECURITY;
ALTER TABLE eleves ENABLE ROW LEVEL SECURITY;
ALTER TABLE inscriptions_annuelles ENABLE ROW LEVEL SECURITY;
ALTER TABLE demandes_admission ENABLE ROW LEVEL SECURITY;
ALTER TABLE paiements ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Acces complet tarifs" ON tarifs_scolarite;
CREATE POLICY "Acces complet tarifs" ON tarifs_scolarite FOR ALL USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "Acces complet eleves" ON eleves;
CREATE POLICY "Acces complet eleves" ON eleves FOR ALL USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "Acces complet inscriptions" ON inscriptions_annuelles;
CREATE POLICY "Acces complet inscriptions" ON inscriptions_annuelles FOR ALL USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "Acces complet demandes" ON demandes_admission;
CREATE POLICY "Acces complet demandes" ON demandes_admission FOR ALL USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "Acces complet paiements" ON paiements;
CREATE POLICY "Acces complet paiements" ON paiements FOR ALL USING (true) WITH CHECK (true);
-- La table utilisateurs n'est pas utilisée par le site : aucune politique = fermée à l'API publique.
DROP POLICY IF EXISTS "Acces complet utilisateurs" ON utilisateurs;

-- ----------------------------------------------------------------------------
-- 8. TEMPS RÉEL : c'est CE bloc qui fait apparaître instantanément chez la
--    secrétaire ce qu'un parent fait de l'autre côté de la ville.
-- ----------------------------------------------------------------------------
DO $$
DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY['eleves','paiements','demandes_admission','tarifs_scolarite']
  LOOP
    BEGIN
      EXECUTE format('ALTER PUBLICATION supabase_realtime ADD TABLE public.%I', t);
    EXCEPTION WHEN duplicate_object THEN NULL;
    END;
  END LOOP;
END $$;

-- ----------------------------------------------------------------------------
-- 9. VUES D'ANALYSE (facultatives)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE VIEW vue_recouvrement_par_classe AS
SELECT e.annee_scolaire, e.classe, COUNT(e.id) AS nombre_eleves,
       COALESCE(SUM(e.scolarite_totale),0) AS total_exigible,
       COALESCE(SUM(e.montant_paye),0) AS total_recouvre,
       COALESCE(SUM(e.scolarite_totale - e.montant_paye),0) AS reste_a_recouvrer
FROM eleves e WHERE e.statut_inscription = 'inscrit'
GROUP BY e.annee_scolaire, e.classe;
